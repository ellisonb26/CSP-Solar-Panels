import java.util.ArrayList;
import java.util.Scanner;

public class SolarAnalysis {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<SolarPanel> dataList = new ArrayList<>();

        // Ask the user how many data points they want to enter
        System.out.print("Enter the number of solar panel data points: ");
        int numDataPoints = scanner.nextInt();

        // User inputs data points
        for (int i = 0; i < numDataPoints; i++) {
            System.out.print("Enter sunlight hours for panel " + (i + 1) + ": ");
            double sunlightHours = scanner.nextDouble();

            System.out.print("Enter temperature (°C) for panel " + (i + 1) + ": ");
            double temperature = scanner.nextDouble();

            System.out.print("Enter power generated (kW) for panel " + (i + 1) + ": ");
            double powerGenerated = scanner.nextDouble();

            dataList.add(new SolarPanel(sunlightHours, temperature, powerGenerated));
        }

        // Analyze the data
        analyzeData(dataList);

        // Close scanner
        scanner.close();
    }

    public static void analyzeData(ArrayList<SolarPanel> dataList) {
        double totalPower = 0;
        double maxPower = Double.MIN_VALUE;
        double minPower = Double.MAX_VALUE;

        for (SolarPanel panel : dataList) {
            totalPower += panel.powerGenerated;

            if (panel.powerGenerated > maxPower) {
                maxPower = panel.powerGenerated;
            }
            if (panel.powerGenerated < minPower) {
                minPower = panel.powerGenerated;
            }
        }

        double averagePower = totalPower / dataList.size();

        System.out.println("\n--- Data Analysis Results ---");
        System.out.println("Average Power Output: " + averagePower + " kW");
        System.out.println("Max Power Output: " + maxPower + " kW");
        System.out.println("Min Power Output: " + minPower + " kW");

        // Let user predict power for new conditions
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter sunlight hours for prediction: ");
        double inputSunlight = scanner.nextDouble();
        System.out.print("Enter temperature (°C) for prediction: ");
        double inputTemp = scanner.nextDouble();
        double predictedPower = predictPower(inputSunlight, inputTemp);
        System.out.println("Predicted Power Output: " + predictedPower + " kW");
        scanner.close();
    }

    public static double predictPower(double sunlightHours, double temperature) {
        double k = 5.0;
        double alpha = 0.005;
        double T_opt = 25;

        return k * sunlightHours * (1 - alpha * (temperature - T_opt));
    }
}