import java.io.*;
import java.util.*;

public class SolarPanel {

    //variables
    double sunlightHours;
    double temperature;
    double powerGenerated;

    //constructor
    public SolarPanel(double sunlightHours, double temperature, double powerGenerated) {
        this.sunlightHours = sunlightHours;
        this.temperature = temperature;
        this.powerGenerated = powerGenerated;
    }

}
